package Human;

import Human.Student.AITUstudent;
import Human.Student.ENUstudent;
import Human.Student.KBTUstudent;
import Human.Student.Student;
import Human.Teacher.EnglishTeacher;
import Human.Teacher.MathTeacher;
import Human.Teacher.Teacher;

//instead of writing all the above imports from each package class, I can instead just simply write (import Human.Student.*; and import Human.Teacher.*;)
//creating several packages in one main package consists the reuse/release equivalence principle.
//changing only 1 class of a package, without changing other packages' classes consists the common closure principle.
//by collecting in one package several classes, which can be considered as a type or subclass of that class refers to the common reuse principle.
//Classes and modules that make up a component should all be releasable together.

public class Main {
    public static void main(String[] args) {
        Student aitushnik = new AITUstudent();
        ((AITUstudent) aitushnik).intro("Venera");

        Student enushnik = new ENUstudent();
        ((ENUstudent) enushnik).intro("Danil");

        Student kbtushnik = new KBTUstudent();
        ((KBTUstudent) kbtushnik).intro ("Islam");

        ((KBTUstudent) kbtushnik).change("AITU");
        //if we change(add or delete) something in a class of a package, other classes from that package are not affected by this change, which refers to the CCP

        System.out.println(" ");

        Teacher math = new MathTeacher();
        ((MathTeacher) math).interview ("Ruslan", 35);

        Teacher eng = new EnglishTeacher();
        ((EnglishTeacher) eng).interview ("Timur", 26);
    }
}
