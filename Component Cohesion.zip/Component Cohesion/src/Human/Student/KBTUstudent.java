package Human.Student;

public class KBTUstudent extends Student{

    public KBTUstudent (){
        super();
    }

    public void intro (String name){
        System.out.println("Hello, i am a student at KBTU and my name is "+name+".");
    }
    public void change (String oldUni){
        System.out.println("I have changed my university to KBTU from "+oldUni+".");
    }
}
