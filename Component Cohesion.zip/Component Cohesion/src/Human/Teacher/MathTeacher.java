package Human.Teacher;

public class MathTeacher extends Teacher {
    public MathTeacher (){
        super();
    }

    public void interview (String name, int age){
        System.out.println("Good morning, my name is "+name+" and I am "+age+" years old. I am going to be your math teacher!");
    }


}
