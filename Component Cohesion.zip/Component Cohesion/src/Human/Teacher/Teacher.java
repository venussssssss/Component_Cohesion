package Human.Teacher;

public abstract class Teacher {
    public String name;
    public int age;

    public Teacher(){}
    public Teacher (String name, int age){
        this.name=name;
        this.age=age;
    }
}
