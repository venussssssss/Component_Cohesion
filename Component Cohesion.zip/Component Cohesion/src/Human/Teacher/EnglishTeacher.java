package Human.Teacher;

public class EnglishTeacher extends Teacher {
    public EnglishTeacher (){
        super();
    }

    public void interview (String name, int age){
        System.out.println("Good morning, my name is "+name+" and I am "+age+" years old.I am going to be your English teacher!");
    }
}
