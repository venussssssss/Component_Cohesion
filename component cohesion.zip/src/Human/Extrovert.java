package Human;

public class Extrovert {
    public void speak (){
        System.out.println("I am an extrovert, that's why I am very confident and active person.");
    }
}
