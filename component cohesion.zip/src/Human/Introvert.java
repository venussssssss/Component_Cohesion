package Human;

public class Introvert {
    public void speak (){
        System.out.println("I am an introvert, that's why I am very shy and quiet person.");
    }

}
