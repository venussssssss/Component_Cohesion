package Human.Student;

public class ENUstudent extends Student {

    public ENUstudent (){
        super();
    }

    public void intro (String name){
        System.out.println("Hello, i am a student at ENU and my name is "+name+".");
    }
}
