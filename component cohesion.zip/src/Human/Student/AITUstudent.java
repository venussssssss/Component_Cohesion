package Human.Student;

public class AITUstudent extends Student {

    public AITUstudent (){
        super();
    }

    public void intro (String name){
        System.out.println("Hello, i am a student at AITU and my name is "+name+".");
    }
}
