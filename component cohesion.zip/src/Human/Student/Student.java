package Human.Student;

public abstract class Student {
    public String name;

    public Student (){}
    public Student (String name){
        this.name=name;
    }
}
